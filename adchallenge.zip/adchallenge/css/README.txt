This is a place for css files. This should only be compiled using Sass files and not directly written here.

Theme is set up to use style.css file in this folder. If you'll create more files, update adchallenge.libraries.yml file.